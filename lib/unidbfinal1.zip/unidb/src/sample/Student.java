package sample;

public class Student {

}
